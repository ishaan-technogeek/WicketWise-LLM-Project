# dataset_selection.py

import os
import json
import sqlite3
from typing import List, Dict, Any, Union

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

from database import create_connection, get_table_schema

class DatasetSelectionAgent:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY not set for DatasetSelectionAgent")

        # Build an LLMChain that asks: "Given this query & list of tables, return a JSON array of the relevant table names"
        prompt = PromptTemplate(
            input_variables=["query", "tables"],
            template=(
                "You are a data engineering assistant.  "
                "Given the user request and the list of available database tables, "
                "select which tables are needed to answer the request.  "
                "Return **only** a JSON array of table names (e.g. [\"players\",\"matches\"]).\n\n"
                "User request:\n{query}\n\n"
                "Available tables:\n{tables}"
            )
        )
        self.chain = LLMChain(
            llm=ChatGoogleGenerativeAI(
                model="gemini-1.5-flash",
                google_api_key=self.api_key
            ),
            prompt=prompt
        )
    
    def _list_all_tables(self, conn: sqlite3.Connection) -> List[str]:
        cur = conn.cursor()
        cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"
        )
        return [row[0] for row in cur.fetchall()]

    def select_dataset(
        self,
        query_or_plan: Union[str, Dict[str, Any]],
        connection: sqlite3.Connection = None
    ) -> Dict[str, Any]:
        """
        Uses an LLM to pick which tables to query.

        Returns:
          {
            "selected_tables": [...],
            "relevant_fields": {
               table1: [col1, col2, ...],
               ...
            }
          }
        """
        own_conn = False
        if connection is None:
            connection = create_connection("wicketwise.db")
            own_conn = True

        try:
            # Normalize the user input to a string
            user_query = (
                query_or_plan if isinstance(query_or_plan, str)
                else json.dumps(query_or_plan)
            )
            print(f"User query: {user_query}")
            # 1. List all tables in the DB
            all_tables = self._list_all_tables(connection)
            tables_str = ", ".join(all_tables)
            print(f"Available tables: {tables_str}")
            resp = self.chain.run(query=user_query, tables=tables_str).strip()
            print(f"LLM response: {resp}")
# Remove markdown wrappers like ```json ... ```
            if resp.startswith("```json"):
                resp = resp.removeprefix("```json").strip()
            if resp.endswith("```"):
                resp = resp.removesuffix("```").strip()

            # 3. Parse the JSON array response
            try:
                selected = json.loads(resp)
                if not isinstance(selected, list):
                    raise ValueError("LLM did not return a JSON array")
            except Exception as e:
                raise ValueError(f"Failed to parse LLM response as JSON list: {e}\nResponse was: {resp}")

            # 4. For each table, fetch its column schema
            relevant_fields: Dict[str, List[str]] = {}
            for tbl in selected:
                try:
                    cols = get_table_schema(tbl, connection)
                except Exception:
                    cols = []
                relevant_fields[tbl] = cols
                # print(f"Table: {tbl}, Columns: {cols}")

            print(f"Selected tables: {selected}")
            print(f"Relevant fields: {relevant_fields}")
            return {
                "selected_tables": selected,
                "relevant_fields": relevant_fields
            }
        finally:
            if own_conn:
                connection.close()
