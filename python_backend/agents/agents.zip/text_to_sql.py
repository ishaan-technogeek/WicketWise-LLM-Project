import os
import re
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_core.output_parsers import StrOutputParser


class TextToSQLAgent:
    def __init__(self):
        self.api_key = "AIzaSyAmhHkeeHTSSl-B5quRWebacPYsafYYSvM"  # Replace with your actual API key
        self.llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=self.api_key)
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", """You are a highly skilled SQL expert. Your task is to convert natural language questions into accurate SQL queries based on the provided database schema.
                Ensure your generated SQL is correct and directly executable.

                Database Schema:
                {schema_info}

                Constraints:
                - Only use the columns provided in the schema.
                - Do not include any explanatory text or markdown, just the SQL query.
                - Assume the user wants data from the 'wicketwise.db' database.
                """),
            ("user", "Generate the SQL query for the following request:\n{natural_language_request}\n\nSQL Query:")
        ])

        self.chain = self.prompt | self.llm | StrOutputParser()
    
    
    
    def generate_sql(self, user_query: str, schema_info: str) -> str:
        response = self.chain.invoke({
            "schema_info": schema_info,
            "natural_language_request": user_query  
        })
        if response.startswith("```sql"):
            response = response.removeprefix("```sql").strip()
        if response.endswith("```"):
            response = response.removesuffix("```").strip()
        print(f"Generated SQL: {response}")
        return response



